<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/jwt.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PATCH");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Get JWT token from header
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
$token = str_replace('Bearer ', '', $authHeader);
$userData = validateJWT($token);

if (!$userData) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

$orderId = $_GET['id'] ?? null;
$data = json_decode(file_get_contents("php://input"));

if ($_SERVER['REQUEST_METHOD'] === 'PATCH' && $orderId && !empty($data->status)) {
    try {
        // Check if user is delivery personnel
        if ($userData['role'] !== 'delivery') {
            http_response_code(403);
            echo json_encode(["message" => "Forbidden - Delivery personnel only"]);
            exit;
        }
        
        // Validate status transition
        $stmt = $pdo->prepare("SELECT status FROM orders WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $currentStatus = $stmt->fetchColumn();
        
        $validTransitions = [
            'pending' => ['shipped'],
            'shipped' => ['delivered']
        ];
        
        if (!isset($validTransitions[$currentStatus])) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid current status"]);
            exit;
        }
        
        if (!in_array($data->status, $validTransitions[$currentStatus])) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid status transition"]);
            exit;
        }
        
        // Update order status
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $stmt->execute([$data->status, $orderId]);
        
        // Update delivery status
        $deliveryStatus = $data->status === 'shipped' ? 'in_transit' : 'delivered';
        $deliveryDate = $data->status === 'delivered' ? date('Y-m-d H:i:s') : null;
        
        $stmt = $pdo->prepare("
            UPDATE deliveries 
            SET status = ?, delivery_date = ?
            WHERE order_id = ?
        ");
        $stmt->execute([$deliveryStatus, $deliveryDate, $orderId]);
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Order status updated",
            "new_status" => $data->status
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["message" => "Failed to update order status"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["message" => "Invalid request"]);
}
?>