<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/jwt.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Get JWT token from header
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
error_log("Raw Authorization Header: " . $authHeader);
$token = str_replace('Bearer ', '', $authHeader);
$userData = validateJWT($token);

if (!$userData) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get orders for the authenticated user
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ?");
    $stmt->execute([$userData['userId']]);
    $orders = $stmt->fetchAll();
    
    // Get order items for each order
    foreach ($orders as &$order) {
        $stmt = $pdo->prepare("
            SELECT oi.*, p.name 
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$order['order_id']]);
        $order['items'] = $stmt->fetchAll();
    }
    
    http_response_code(200);
    echo json_encode($orders);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create new order
    $data = json_decode(file_get_contents("php://input"));
    
    if (!empty($data->items) && is_array($data->items)) {
        try {
            $pdo->beginTransaction();
            
            // Calculate total amount
            $totalAmount = 0;
            foreach ($data->items as $item) {
                // Get product price from database to prevent tampering
                $stmt = $pdo->prepare("SELECT price FROM products WHERE product_id = ?");
                $stmt->execute([$item->product_id]);
                $product = $stmt->fetch();
                
                if (!$product) {
                    throw new Exception("Product not found");
                }
                
                $totalAmount += $product['price'] * $item->quantity;
            }
            
            // Create order
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount) VALUES (?, ?)");
            $stmt->execute([$userData['userId'], $totalAmount]);
            $orderId = $pdo->lastInsertId();
            
            // Add order items
            foreach ($data->items as $item) {
                $stmt = $pdo->prepare("
                    INSERT INTO order_items (order_id, product_id, quantity, price)
                    VALUES (?, ?, ?, (SELECT price FROM products WHERE product_id = ?))
                ");
                $stmt->execute([$orderId, $item->product_id, $item->quantity, $item->product_id]);
                
                // Update product stock
                $stmt = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE product_id = ?");
                $stmt->execute([$item->quantity, $item->product_id]);
            }
            
            // Create delivery record
            $stmt = $pdo->prepare("
                INSERT INTO deliveries (order_id, assigned_to)
                VALUES (?, (SELECT user_id FROM users WHERE role = 'delivery' ORDER BY RAND() LIMIT 1))
            ");
            $stmt->execute([$orderId]);
            
            $pdo->commit();
            
            http_response_code(201);
            echo json_encode([
                "success" => true,
                "message" => "Order created successfully",
                "order_id" => $orderId,
                "total_amount" => $totalAmount
            ]);
        } catch (Exception $e) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode([
                "success" => false,
                "message" => "Order creation failed: " . $e->getMessage()
            ]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["message" => "Invalid order data"]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    // Handle order status updates
    $orderId = $_GET['id'] ?? null;
    $data = json_decode(file_get_contents("php://input"));
    
    if (!$orderId || empty($data->status)) {
        http_response_code(400);
        echo json_encode(["message" => "Order ID and status are required"]);
        exit;
    }

    // Check if user is delivery personnel
    if ($userData['role'] !== 'delivery') {
        http_response_code(403);
        echo json_encode(["message" => "Forbidden - Delivery personnel only"]);
        exit;
    }
    
    // Validate status transition
    $validStatuses = ['pending', 'shipped', 'delivered'];
    if (!in_array($data->status, $validStatuses)) {
        http_response_code(400);
        echo json_encode(["message" => "Invalid status value"]);
        exit;
    }
    
    try {
        // Get current status
        $stmt = $pdo->prepare("SELECT status FROM orders WHERE order_id = ?");
        $stmt->execute([$orderId]);
        $currentStatus = $stmt->fetchColumn();
        
        // Validate status transition
        $validTransitions = [
            'pending' => ['shipped'],
            'shipped' => ['delivered']
        ];
        
        if (!isset($validTransitions[$currentStatus]) || 
            !in_array($data->status, $validTransitions[$currentStatus])) {
            http_response_code(400);
            echo json_encode(["message" => "Invalid status transition"]);
            exit;
        }
        
        // Update order status
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $stmt->execute([$data->status, $orderId]);
        
        // Update delivery status
        $deliveryStatus = ($data->status === 'shipped') ? 'in_transit' : 'delivered';
        $deliveryDate = ($data->status === 'delivered') ? date('Y-m-d H:i:s') : null;
        
        $stmt = $pdo->prepare("UPDATE deliveries SET status = ?, delivery_date = ? WHERE order_id = ?");
        $stmt->execute([$deliveryStatus, $deliveryDate, $orderId]);
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Order status updated",
            "new_status" => $data->status
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["message" => "Failed to update order status: " . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(["message" => "Method not allowed"]);
}
?>