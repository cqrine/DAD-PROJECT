<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/jwt.php';

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->username) && !empty($data->password)) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$data->username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($data->password, $user['password'])) {
        $token = generateJWT($user['user_id'], $user['username'], $user['role']);
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Login successful",
            "token" => $token,
            "user_id" => $user['user_id'],
            "role" => $user['role']
        ]);
    } else {
        http_response_code(401);
        echo json_encode(["success" => false, "message" => "Invalid username or password"]);
    }
} else {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Username and password are required"]);
}
?>