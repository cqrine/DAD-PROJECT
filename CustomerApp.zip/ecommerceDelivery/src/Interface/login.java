package Interface;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class login {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/* Launch the application.*/
	
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				login window = new login();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/*Create the application.*/
	
	public login() {
		initialize();
	}
	
	public void showWindow() {
	    frame.setVisible(true);
	}

	/* Initialize the contents of the frame. */
	
	@SuppressWarnings("unused")
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("E-Commerce Delivery System");
		frame.setBounds(100, 100, 800, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel contentPane = new JPanel();
		contentPane.setBackground(new Color(243, 112, 33)); // Green background
		contentPane.setLayout(null);
		frame.setContentPane(contentPane);

		//title
		JLabel lblTitle = new JLabel("Pantas Express");
		lblTitle.setForeground(new Color(255, 255, 255));
		lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 70));
		lblTitle.setBounds(100, 50, 600, 100);
		contentPane.add(lblTitle);

		// Username label and field
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setFont(new Font("Comic Sans", Font.PLAIN, 24));
		lblUsername.setForeground(new Color(255, 255, 255));
		lblUsername.setBounds(206, 210, 177, 55);
		contentPane.add(lblUsername);

		textField = new JTextField();
		textField.setBounds(332, 222, 211, 33);
		contentPane.add(textField);
		textField.setColumns(10);

		// Password label and field
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setFont(new Font("Comic Sans", Font.PLAIN, 24));
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setBounds(206, 275, 177, 55);
		contentPane.add(lblPassword);

		textField_1 = new JPasswordField();
		textField_1.setColumns(10);
		textField_1.setBounds(332, 281, 211, 33);
		contentPane.add(textField_1);

		// Login button
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.setFont(new Font("Consolas", Font.PLAIN, 18));
		btnLogin.setBounds(259, 348, 159, 45);
		contentPane.add(btnLogin);

		btnLogin.addActionListener(e -> {
			String username = textField.getText();
			String password = new String(((JPasswordField) textField_1).getPassword());

			// You can replace this with controller call
			System.out.println("Login clicked. Username: " + username + ", Password: " + password);
			// Example:
			// Login_Controller loginController = new Login_Controller();
			// loginController.handleLogin(username, password);
		});

		// Sign Up button
		JButton btnSignUp = new JButton("SIGN UP");
		btnSignUp.setFont(new Font("Consolas", Font.PLAIN, 18));
		btnSignUp.setBounds(440, 348, 159, 45);
		contentPane.add(btnSignUp);

		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		}); 

		// Exit button
		JButton btnExit = new JButton("EXIT");
		btnExit.setFont(new Font("Consolas", Font.PLAIN, 18));
		btnExit.setBounds(365, 400, 159, 39);
		contentPane.add(btnExit);

		btnExit.addActionListener(e -> System.exit(0));
		
		// Inside your btnLogin ActionListener:
		// Login button action: open Product window
		btnLogin.addActionListener(e -> {
		    String username = textField.getText();
		    String password = textField_1.getText();

		    // Optional: Add basic validation
		    if (username.isEmpty() || password.isEmpty()) {
		        JOptionPane.showMessageDialog(frame, "Please enter both username and password.", "Login Error", JOptionPane.ERROR_MESSAGE);
		        return;
		    }

		    // Open Product window
		    product productWindow = new product();
		    productWindow.showWindow(); // <-- this must exist in your product.java
		    frame.dispose();
		});

		// Sign Up button action: open Register window
		btnSignUp.addActionListener(e -> {
		    register registerWindow = new register();
		    registerWindow.showWindow(); // <-- this must exist in your register.java
		    frame.dispose();
		});

	}
}
