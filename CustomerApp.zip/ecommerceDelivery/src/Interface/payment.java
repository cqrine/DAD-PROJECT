package Interface;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class payment extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtStatus;
    private JTextArea textAmount;

    public payment(double totalAmount, List<String> cartItems) {
        setTitle("Payment Page");
        setBounds(100, 100, 800, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        contentPane = new JPanel();
        contentPane.setBackground(new Color(243, 112, 33));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Payment");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 50));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(10, 10, 760, 78);
        contentPane.add(lblTitle);

        JLabel lblAmount = new JLabel("Total Amount      : RM");
        lblAmount.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        lblAmount.setForeground(Color.WHITE);
        lblAmount.setBounds(200, 120, 200, 30);
        contentPane.add(lblAmount);

        JLabel lblStatus = new JLabel("Status                 :");
        lblStatus.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        lblStatus.setForeground(Color.WHITE);
        lblStatus.setBounds(200, 170, 200, 30);
        contentPane.add(lblStatus);

        JLabel lblMethod = new JLabel("Payment Method:");
        lblMethod.setFont(new Font("Comic Sans MS", Font.BOLD, 16));
        lblMethod.setForeground(Color.WHITE);
        lblMethod.setBounds(200, 220, 200, 30);
        contentPane.add(lblMethod);

        txtStatus = new JTextField("Pending");
        txtStatus.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        txtStatus.setBounds(400, 170, 150, 30);
        contentPane.add(txtStatus);

        textAmount = new JTextArea(String.format("%.2f", totalAmount));
        textAmount.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        textAmount.setBounds(400, 120, 150, 30);
        textAmount.setEditable(false);
        contentPane.add(textAmount);

        JList<String> methodList = new JList<>(new String[]{"TnG e-Wallet", "FPX Online Banking", "Visa Card", "Cash"});
        methodList.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        methodList.setBounds(400, 220, 150, 90);
        contentPane.add(methodList);

        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.setFont(new Font("Consolas", Font.PLAIN, 18));
        btnConfirm.setBounds(460, 340, 120, 35);
        contentPane.add(btnConfirm);

        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Consolas", Font.PLAIN, 18));
        btnBack.setBounds(220, 340, 120, 35);
        contentPane.add(btnBack);

        btnConfirm.addActionListener(e -> {
            String method = methodList.getSelectedValue();
            if (method == null) {
                JOptionPane.showMessageDialog(this, "Please select a payment method.", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Payment successful via " + method + "!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            }
        });

        btnBack.addActionListener(e -> dispose());
    }
}
